/*
*********************************************************************************************************
*                                              EXAMPLE CODE
*
*                              (c) Copyright 2010; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                              EXAMPLE CODE
*											      NUVOTON
*                                        NUC100 Evaluation Board
*
* Filename      : app.c
* Version       : V1.00
* Programmer(s) : Ken
*********************************************************************************************************
*/
#include <ucos_ii.h>
//#include "app_cfg.h" 
#include "cpu.h"

#include <stdio.h>
#include "Driver\DrvUART.h"
#include "Driver\DrvGPIO.h"
#include "NUC1xx.h"
#include "DrvSYS.h"

//#include <stdlib.h>

/*
*********************************************************************************************************
*                                             LOCAL DEFINES
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                            LOCAL VARIABLES
*********************************************************************************************************
*/

#define FLAG_TEST
#define STACKSIZE 128



#ifdef FLAG_TEST
OS_STK SYS_Task_Stack[STACKSIZE]; 
#define SYS_Task_Prio				51
void SYS_Task(void *Id);

OS_STK Task1_Stack[STACKSIZE]; 
void Task1(void *Id);
#define Task1_Prio     52

OS_FLAG_GRP *EngineFlags;
INT8U EngineName[30];

#define ENGINE_OK 0x01
#define ENGINE_ERROR 0x02
#endif




/*
*********************************************************************************************************
*                                            LOCAL FUCTION
*********************************************************************************************************
*/
/*
int32_t BSP_INIT_UART0(void)
{
	STR_UART_T param;
	DrvGPIO_InitFunction(FUNC_UART0);
	
    param.u32BaudRate        = 115200;
    param.u8cDataBits        = DRVUART_DATABITS_8;
    param.u8cStopBits        = DRVUART_STOPBITS_1;
    param.u8cParity          = DRVUART_PARITY_NONE;
    param.u8cRxTriggerLevel  = DRVUART_FIFO_1BYTES;
    param.u8TimeOut        	 = 0;
    if(DrvUART_Open(UART_PORT0,&param) == 0)
		return TRUE;
	else
		return FALSE;
}
*/


void SysTick_Handler(void)
{
	OS_CPU_SR  cpu_sr;

    OS_ENTER_CRITICAL();;                                       
    OSIntNesting++;
    OS_EXIT_CRITICAL();

	OSTimeTick();

	OSIntExit();
}

void Delay(uint32_t delayCnt)
{
    while(delayCnt--)
    {
        __NOP();
        __NOP();
    }
}

/*
*********************************************************************************************************
*                                                main()
*
* Description : This is the standard entry point for C code.  It is assumed that your code will call
*               main() once you have performed all necessary C initialization.
*
* Argument(s) : none.
*
* Return(s)   : none.
*********************************************************************************************************
*/


int  main (void)
{
  STR_UART_T param;
  UNLOCKREG();
  SYSCLK->PWRCON.OSC22M_EN = 1;//default is enabled 
  SYSCLK->PWRCON.XTL12M_EN = 1;
  SYSCLK->CLKSEL0.HCLK_S = 0;//using 12M as HCLK src
  Delay(100);
    
  /* Configure UART0 related pins */
  DrvGPIO_InitFunction(E_FUNC_UART0);
    
  /* Select UART Clock Source From 12MHz */
  DrvSYS_SelectIPClockSource(E_SYS_UART_CLKSRC,0);

  /* UART configuration */
  param.u32BaudRate        = 115200;
  param.u8cDataBits        = DRVUART_DATABITS_8;
  param.u8cStopBits        = DRVUART_STOPBITS_1;
  param.u8cParity          = DRVUART_PARITY_NONE;
  param.u8cRxTriggerLevel  = DRVUART_FIFO_1BYTES;
  param.u8TimeOut          = 0;

  DrvUART_Open(UART_PORT0, &param);    
    
    
  OSInit();
  UNLOCKREG();

  SysTick_Config(120000);

  OSTaskCreate(SYS_Task,  (void *)0,  (OS_STK *)&SYS_Task_Stack[STACKSIZE-1],  SYS_Task_Prio);
  OSStart();                                                  /* Start multitasking (i.e. give control to uC/OS-II).  */
}

#ifdef FLAG_TEST
void Task1(void *Id)
{
	INT8U err;
	OS_FLAGS value;
	
	(void)Id;//remove warning
	
	for(;;){
		printf("\tTask1 is running\n");
		OSTimeDly(100);
		value = OSFlagPend(EngineFlags,
					ENGINE_OK,
					OS_FLAG_WAIT_SET_ALL + OS_FLAG_CONSUME,//clr flag after be read
					0,//0 for forever
					&err);
		if(err == OS_ERR_NONE)
		{
			printf("\tTask1 get flag %x\n", value);
		}
		else
			printf("\tTask1 wait flag error %d\n", err);
	}
}


void SYS_Task(void *Id)
{   
    INT8U err;//, size;
	OS_FLAG_GRP *pgrp;
	uint32_t Temp=100000;
	
	(void)Id;//remove warning
	
	EngineFlags = OSFlagCreate(0x00, &err);

/*	size = OSFlagNameGet(EngineFlags,
			&EngineName[0],
			&err);
  */
	OSFlagNameGet(EngineFlags,
			&EngineName[0],
			&err);
	
	if(err == OS_ERR_NONE)
	{
		printf("FlagName is %s\n", EngineName);
	}
	
	OSTaskCreate(Task1,  (void *)0,  (OS_STK *)&Task1_Stack[STACKSIZE-1],  Task1_Prio);
	for (;Temp;Temp--)
	{
		printf("Main_task is running.\n");
		
		OSTimeDly(150);
		
		if((GPIOB->PIN & (1 << 15)) != 0)
		{
		err = OSFlagPost(EngineFlags,
					ENGINE_OK,
					OS_FLAG_SET,
					&err);
		}
		else
		{
        err = OSFlagPost(EngineFlags,
					ENGINE_ERROR,
					OS_FLAG_SET,
					&err);		 
		}
	}

	
	pgrp = OSFlagDel(EngineFlags, OS_DEL_ALWAYS, &err);
	if (pgrp == (OS_FLAG_GRP *)0) {
		/* The event flag group was deleted */
		printf("The event flag group was deleted \n");
	}
	
}
#endif



/*
*********************************************************************************************************
*********************************************************************************************************
**                                         uC/OS-II APP HOOKS
*********************************************************************************************************
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      TASK CREATION HOOK (APPLICATION)
*
* Description : This function is called when a task is created.
*
* Argument(s) : ptcb   is a pointer to the task control block of the task being created.
*
* Note(s)     : (1) Interrupts are disabled during this call.
*********************************************************************************************************
*/
#if OS_APP_HOOKS_EN > 0
void  App_TaskCreateHook (OS_TCB *ptcb)
{
	(void)ptcb;
}
#endif
/*
*********************************************************************************************************
*                                    TASK DELETION HOOK (APPLICATION)
*
* Description : This function is called when a task is deleted.
*
* Argument(s) : ptcb   is a pointer to the task control block of the task being deleted.
*
* Note(s)     : (1) Interrupts are disabled during this call.
*********************************************************************************************************
*/
#if OS_APP_HOOKS_EN > 0
void  App_TaskDelHook (OS_TCB *ptcb)
{
    (void)ptcb;
}
#endif
/*
*********************************************************************************************************
*                                      IDLE TASK HOOK (APPLICATION)
*
* Description : This function is called by OSTaskIdleHook(), which is called by the idle task.  This hook
*               has been added to allow you to do such things as STOP the CPU to conserve power.
*
* Argument(s) : none.
*
* Note(s)     : (1) Interrupts are enabled during this call.
*********************************************************************************************************
*/
#if OS_APP_HOOKS_EN > 0 && OS_VERSION >= 251
void  App_TaskIdleHook (void)
{
}
#endif
/*
*********************************************************************************************************
*                                        STATISTIC TASK HOOK (APPLICATION)
*
* Description : This function is called by OSTaskStatHook(), which is called every second by uC/OS-II's
*               statistics task.  This allows your application to add functionality to the statistics task.
*
* Argument(s) : none.
*********************************************************************************************************
*/
#if OS_APP_HOOKS_EN > 0
void  App_TaskStatHook (void)
{
}
#endif
/*
*********************************************************************************************************
*                                        TASK SWITCH HOOK (APPLICATION)
*
* Description : This function is called when a task switch is performed.  This allows you to perform other
*               operations during a context switch.
*
* Argument(s) : none.
*
* Note(s)     : (1) Interrupts are disabled during this call.
*
*               (2) It is assumed that the global pointer 'OSTCBHighRdy' points to the TCB of the task that
*                   will be 'switched in' (i.e. the highest priority task) and, 'OSTCBCur' points to the
*                  task being switched out (i.e. the preempted task).
*********************************************************************************************************
*/

#if OS_APP_HOOKS_EN > 0 && OS_TASK_SW_HOOK_EN > 0
void  App_TaskSwHook (void)
{
}
#endif

/*
*********************************************************************************************************
*                                     OS_TCBInit() HOOK (APPLICATION)
*
* Description : This function is called by OSTCBInitHook(), which is called by OS_TCBInit() after setting
*               up most of the TCB.
*
* Argument(s) : ptcb    is a pointer to the TCB of the task being created.
*
* Note(s)     : (1) Interrupts may or may not be ENABLED during this call.
*********************************************************************************************************
*/

#if OS_APP_HOOKS_EN > 0 && OS_VERSION >= 204
void  App_TCBInitHook (OS_TCB *ptcb)
{
    (void)ptcb;
}
#endif

/*
*********************************************************************************************************
*                                        TICK HOOK (APPLICATION)
*
* Description : This function is called every tick.
*
* Argument(s) : none.
*
* Note(s)     : (1) Interrupts may or may not be ENABLED during this call.
*********************************************************************************************************
*/

#if OS_TIME_TICK_HOOK_EN > 0
void  App_TimeTickHook (void)
{
}
#endif
